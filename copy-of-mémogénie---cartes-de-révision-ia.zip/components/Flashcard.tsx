
import React, { useRef, useState } from 'react';
import { FlashcardContent } from '../types';
import { toPng } from 'html-to-image';

interface FlashcardProps {
  content: FlashcardContent;
  onBack: () => void;
  onDelete?: (id: string) => void;
  onStartExercise?: (card: FlashcardContent) => void;
  isExerciseLoading?: boolean;
}

const Flashcard: React.FC<FlashcardProps> = ({ content, onBack, onDelete, onStartExercise, isExerciseLoading }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    
    setIsDownloading(true);
    try {
      // On capture la fiche avec un ratio de pixel élevé pour la qualité (Retina/HD)
      // On filtre pour ne pas inclure les éléments avec la classe 'no-print' dans l'image
      const dataUrl = await toPng(cardRef.current, { 
        cacheBust: true, 
        pixelRatio: 2,
        backgroundColor: '#ffffff',
        filter: (node) => {
          const classList = (node as HTMLElement).classList;
          return classList ? !classList.contains('no-print') : true;
        }
      });
      
      const link = document.createElement('a');
      const filename = `${content.title.replace(/\s+/g, '_')}_${content.level}.png`;
      link.download = filename;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Erreur lors du téléchargement de l\'image', err);
      alert('Désolé, le téléchargement a échoué. Réessaie ou utilise la fonction impression.');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto mt-4 mb-20 animate-in fade-in slide-in-from-bottom-6 duration-500">
      <div className="no-print mb-6 flex justify-between items-center">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-medium transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
          Retour
        </button>
        <div className="flex gap-2">
          {onStartExercise && (
            <button 
              disabled={isExerciseLoading || isDownloading}
              onClick={() => onStartExercise(content)}
              className="px-4 py-2 bg-purple-50 text-purple-700 rounded-xl font-bold hover:bg-purple-100 flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              {isExerciseLoading ? (
                <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
              )}
              S'entraîner
            </button>
          )}
          <button 
            onClick={handleDownload} 
            disabled={isDownloading}
            className="bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-indigo-700 shadow-md flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
          >
            {isDownloading ? (
              <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
            )}
            {isDownloading ? "Génération..." : "Télécharger"}
          </button>
        </div>
      </div>

      <div ref={cardRef} className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-200 print-card flex flex-col min-h-[800px]">
        <div className="h-3 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 no-print"></div>
        
        <div className="p-10 md:p-14 flex-grow">
          <div className="text-center mb-12">
            <div className="inline-block px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
              {content.level} • {content.subject}
            </div>
            <h2 className="font-serif text-5xl font-bold text-slate-900 mb-4 leading-tight">
              {content.title}
            </h2>
            <p className="text-indigo-800 font-bold uppercase tracking-[0.3em] text-[11px]">
              {content.subtitle}
            </p>
          </div>

          {content.imageUrl && (
            <div className="mb-12 rounded-3xl overflow-hidden border border-slate-100 shadow-lg bg-slate-50">
              <img src={content.imageUrl} alt={content.title} className="w-full h-auto object-cover max-h-[350px]" />
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-12">
            <div className="space-y-10">
              <section>
                <h3 className="text-slate-900 text-[11px] font-black uppercase tracking-[0.2em] mb-4 border-b-2 border-indigo-100 pb-2 flex items-center">
                  <span className="w-2 h-2 bg-indigo-600 rounded-full mr-3"></span>
                  L'ESSENTIEL
                </h3>
                <p className="text-slate-900 text-xl italic font-serif leading-relaxed font-semibold">
                  "{content.definition}"
                </p>
              </section>

              <section>
                <h3 className="text-slate-900 text-[11px] font-black uppercase tracking-[0.2em] mb-4 border-b-2 border-indigo-100 pb-2 flex items-center">
                  <span className="w-2 h-2 bg-indigo-600 rounded-full mr-3"></span>
                  POINTS CLÉS
                </h3>
                <ul className="space-y-5">
                  {content.keyPoints.map((point, i) => (
                    <li key={i} className="flex items-start">
                      <div className="h-6 w-6 rounded-lg bg-indigo-100 flex items-center justify-center mr-4 shrink-0 border border-indigo-200">
                        <span className="text-[11px] font-black text-indigo-700">{i + 1}</span>
                      </div>
                      <span className="text-slate-800 leading-snug font-bold text-lg">{point}</span>
                    </li>
                  ))}
                </ul>
              </section>
            </div>

            <div className="space-y-10">
              <section className="bg-slate-900 p-8 rounded-[2rem] shadow-xl transform -rotate-1">
                <h3 className="text-indigo-300 text-[10px] font-black uppercase tracking-widest mb-4 flex items-center">
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2-2v14a2 2 0 002 2z"></path></svg>
                  EXEMPLE / FORMULE
                </h3>
                <p className="font-mono text-white text-xl font-bold break-words leading-relaxed">
                  {content.formulaOrExample}
                </p>
              </section>

              {content.mnemonicDevice && (
                <section className="bg-amber-50 p-6 rounded-2xl border-2 border-dashed border-amber-200 shadow-inner">
                  <span className="text-amber-950 font-handwriting text-2xl block leading-tight">
                    💡 Astuce : {content.mnemonicDevice}
                  </span>
                </section>
              )}

              <section className="pt-6 border-t border-slate-100">
                <p className="text-slate-600 text-sm font-semibold italic">
                  {content.summary}
                </p>
              </section>
            </div>
          </div>

          {/* New Sources Section */}
          {content.sources && content.sources.length > 0 && (
            <div className="mt-12 pt-8 border-t border-slate-100">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.828a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                Sources fiables & Vérification
              </h4>
              <div className="flex flex-wrap gap-2">
                {content.sources.map((source, idx) => (
                  <a 
                    key={idx}
                    href={source.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-3 py-2 bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 rounded-lg text-[11px] font-bold text-slate-600 hover:text-indigo-700 transition-all no-print"
                  >
                    <img src={`https://www.google.com/s2/favicons?domain=${new URL(source.uri).hostname}&sz=32`} alt="" className="w-3 h-3" />
                    {source.title.length > 35 ? source.title.substring(0, 35) + '...' : source.title}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons for Card View */}
        <div className="p-10 pt-0 no-print">
          <button 
            onClick={() => onDelete && onDelete(content.id)}
            className="w-full text-red-500 text-xs font-bold uppercase tracking-widest hover:text-red-700 transition-colors py-4 border-t border-slate-50"
          >
            Supprimer cette fiche définitivement
          </button>
        </div>
      </div>
    </div>
  );
};

export default Flashcard;
