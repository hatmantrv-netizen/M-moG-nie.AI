
import React from 'react';
import { FlashcardContent } from '../types';

interface GalleryProps {
  cards: FlashcardContent[];
  onSelect: (card: FlashcardContent) => void;
  onDelete: (id: string) => void;
}

const Gallery: React.FC<GalleryProps> = ({ cards, onSelect, onDelete }) => {
  if (cards.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-[2.5rem] border-2 border-dashed border-slate-200 max-w-2xl mx-auto">
        <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2">Ta bibliothèque est vide</h3>
        <p className="text-slate-500 mb-8">Génère ta première carte mémo pour la retrouver ici !</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto pb-20">
      {cards.sort((a,b) => b.createdAt - a.createdAt).map(card => (
        <div 
          key={card.id} 
          className="group bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden cursor-pointer flex flex-col"
          onClick={() => onSelect(card)}
        >
          <div className="h-32 bg-slate-100 relative overflow-hidden">
            {card.imageUrl ? (
              <img src={card.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt="" />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-indigo-50 to-purple-50 flex items-center justify-center text-slate-300">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
              </div>
            )}
            <div className="absolute top-3 left-3 px-2 py-1 bg-white/90 backdrop-blur rounded-lg text-[9px] font-black text-indigo-700 uppercase tracking-tighter">
              {card.subject}
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); onDelete(card.id); }}
              className="absolute top-3 right-3 p-2 bg-red-50/90 text-red-500 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500 hover:text-white"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
            </button>
          </div>
          <div className="p-6">
            <h4 className="font-serif font-bold text-slate-900 text-lg mb-1 truncate">{card.title}</h4>
            <p className="text-slate-500 text-xs line-clamp-2 mb-4 leading-relaxed italic">"{card.definition}"</p>
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-medium">
              <span>{card.level}</span>
              <span>{new Date(card.createdAt).toLocaleDateString('fr-FR')}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Gallery;
