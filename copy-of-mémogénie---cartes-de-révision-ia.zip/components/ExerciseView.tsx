
import React, { useState } from 'react';
import { Exercise } from '../types';

interface ExerciseViewProps {
  exercise: Exercise;
  onClose: () => void;
}

const ExerciseView: React.FC<ExerciseViewProps> = ({ exercise, onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const currentQuestion = exercise.questions[currentStep];

  const handleOptionSelect = (index: number) => {
    if (isSubmitted) return;
    setSelectedOption(index);
  };

  const handleSubmit = () => {
    if (selectedOption === null) return;
    setIsSubmitted(true);
    if (selectedOption === currentQuestion.correctAnswerIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentStep < exercise.questions.length - 1) {
      setCurrentStep(s => s + 1);
      setSelectedOption(null);
      setIsSubmitted(false);
    } else {
      setShowResult(true);
    }
  };

  if (showResult) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-[2.5rem] p-12 shadow-2xl text-center animate-in zoom-in-95 duration-500">
        <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-8">
          <span className="text-3xl font-black text-indigo-600">{score}/{exercise.questions.length}</span>
        </div>
        <h2 className="text-3xl font-serif font-bold text-slate-900 mb-4">Entraînement terminé !</h2>
        <p className="text-slate-600 text-lg mb-10">
          {score === exercise.questions.length 
            ? "Félicitations ! Tu maîtrises parfaitement ce sujet. ✨" 
            : "Bon travail ! Continue de réviser pour atteindre le score parfait. 💪"}
        </p>
        <button 
          onClick={onClose}
          className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl hover:bg-indigo-700 transition-all"
        >
          Retour à la fiche
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-100 animate-in fade-in slide-in-from-bottom-8 duration-500">
      <div className="bg-slate-900 p-8 text-white relative">
        <button onClick={onClose} className="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
        <p className="text-indigo-400 text-[10px] font-black uppercase tracking-[0.2em] mb-2">Question {currentStep + 1} sur {exercise.questions.length}</p>
        <h3 className="text-2xl font-serif font-bold leading-tight">{currentQuestion.question}</h3>
      </div>

      <div className="p-8 space-y-4">
        {currentQuestion.options.map((option, index) => {
          let variant = "border-slate-100 hover:border-indigo-200 bg-slate-50";
          if (selectedOption === index) variant = "border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500/20";
          
          if (isSubmitted) {
            if (index === currentQuestion.correctAnswerIndex) variant = "border-emerald-500 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500/20";
            else if (selectedOption === index) variant = "border-red-500 bg-red-50 text-red-900 ring-2 ring-red-500/20 opacity-80";
            else variant = "border-slate-100 opacity-40";
          }

          return (
            <button
              key={index}
              disabled={isSubmitted}
              onClick={() => handleOptionSelect(index)}
              className={`w-full p-5 text-left rounded-2xl border-2 transition-all flex items-center gap-4 ${variant}`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm shrink-0 border ${
                selectedOption === index ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-slate-400 border-slate-200'
              }`}>
                {String.fromCharCode(65 + index)}
              </div>
              <span className="font-semibold text-slate-800">{option}</span>
            </button>
          );
        })}
      </div>

      {isSubmitted && (
        <div className="px-8 pb-4 animate-in fade-in slide-in-from-top-2">
          <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Explication</h4>
            <p className="text-slate-700 text-sm leading-relaxed">{currentQuestion.explanation}</p>
          </div>
        </div>
      )}

      <div className="p-8 pt-0">
        {!isSubmitted ? (
          <button
            onClick={handleSubmit}
            disabled={selectedOption === null}
            className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50"
          >
            Valider ma réponse
          </button>
        ) : (
          <button
            onClick={handleNext}
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
          >
            {currentStep < exercise.questions.length - 1 ? "Question suivante" : "Voir mes résultats"}
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
          </button>
        )}
      </div>
    </div>
  );
};

export default ExerciseView;
