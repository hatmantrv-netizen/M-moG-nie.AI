
import React from 'react';
import { SearchParams, Level, Subject } from '../types';
import { LEVELS, SUBJECTS } from '../constants';

interface SelectionFormProps {
  onSearch: (params: SearchParams) => void;
  isLoading: boolean;
}

const SelectionForm: React.FC<SelectionFormProps> = ({ onSearch, isLoading }) => {
  const [params, setParams] = React.useState<SearchParams>({
    level: '3ème',
    subject: 'Mathématiques',
    topic: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (params.topic.trim()) {
      onSearch(params);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-xl mx-auto space-y-6 bg-white p-8 rounded-3xl shadow-xl border border-slate-100">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Ton niveau</label>
          <select 
            value={params.level}
            onChange={(e) => setParams(p => ({ ...p, level: e.target.value as Level }))}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all appearance-none bg-slate-50"
          >
            {LEVELS.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Matière</label>
          <select 
            value={params.subject}
            onChange={(e) => setParams(p => ({ ...p, subject: e.target.value as Subject }))}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all appearance-none bg-slate-50"
          >
            {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-slate-700 mb-2">Chapitre ou Notion</label>
        <input 
          type="text"
          placeholder="Ex: Le Théorème de Pythagore, La Seconde Guerre Mondiale..."
          value={params.topic}
          onChange={(e) => setParams(p => ({ ...p, topic: e.target.value }))}
          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all placeholder:text-slate-400 bg-slate-50"
          required
        />
      </div>

      <button 
        type="submit"
        disabled={isLoading || !params.topic}
        className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl font-bold text-lg hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-indigo-200/50 disabled:opacity-50 disabled:cursor-not-allowed transform active:scale-[0.98]"
      >
        {isLoading ? (
          <span className="flex items-center justify-center">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Rédaction de ta fiche...
          </span>
        ) : "Générer ma carte mémo"}
      </button>
    </form>
  );
};

export default SelectionForm;
