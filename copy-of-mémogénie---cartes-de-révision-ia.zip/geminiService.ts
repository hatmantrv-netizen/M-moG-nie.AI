
import { GoogleGenAI, Type } from "@google/genai";
import { FlashcardContent, SearchParams, Exercise, SourceLink } from "./types";

const SYSTEM_INSTRUCTION = `Tu es un professeur d'excellence de l'Éducation Nationale française. 
Tu es expert en pédagogie et en mémorisation. 
IMPORTANT: Ton orthographe, ta grammaire et ta ponctuation doivent être ABSOLUMENT PARFAITES. 
Tu ne dois commettre aucune erreur, même mineure. 
Utilise l'outil Google Search pour vérifier la véracité de chaque information, date ou formule scientifique.`;

export const generateFlashcard = async (params: SearchParams, history: FlashcardContent[]): Promise<FlashcardContent> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const historyContext = history.length > 0 
    ? `L'élève a déjà révisé les sujets suivants : ${history.map(h => h.title).join(', ')}.`
    : "";

  const textPrompt = `Génère une fiche de révision structurée pour un élève de ${params.level} en ${params.subject} sur le chapitre : "${params.topic}". 
  ${historyContext}
  
  La fiche doit être synthétique, rigoureuse et basée sur le programme officiel français. 
  Inclus une description d'image précise pour un schéma éducatif.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: textPrompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          subtitle: { type: Type.STRING },
          definition: { type: Type.STRING },
          keyPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
          formulaOrExample: { type: Type.STRING },
          summary: { type: Type.STRING },
          mnemonicDevice: { type: Type.STRING },
          imageDescription: { type: Type.STRING }
        },
        required: ['title', 'subtitle', 'definition', 'keyPoints', 'formulaOrExample', 'summary', 'imageDescription']
      }
    }
  });

  const baseContent = JSON.parse(response.text.trim());
  
  // Extraction des sources (Grounding Metadata)
  const sources: SourceLink[] = [];
  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (groundingChunks) {
    groundingChunks.forEach((chunk: any) => {
      if (chunk.web && chunk.web.uri && chunk.web.title) {
        // Éviter les doublons de domaine
        if (!sources.find(s => s.uri === chunk.web.uri)) {
          sources.push({
            title: chunk.web.title,
            uri: chunk.web.uri
          });
        }
      }
    });
  }
  
  const flashcard: FlashcardContent = {
    ...baseContent,
    id: crypto.randomUUID(),
    createdAt: Date.now(),
    level: params.level,
    subject: params.subject,
    sources: sources.length > 0 ? sources : undefined
  };

  try {
    const imageResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: `Schéma éducatif professionnel, fond blanc, style vectoriel propre, sujet : ${flashcard.imageDescription}.` }]
      },
      config: { imageConfig: { aspectRatio: "16:9" } }
    });

    for (const part of imageResponse.candidates[0].content.parts) {
      if (part.inlineData) {
        flashcard.imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }
  } catch (e) { console.error("Image error", e); }

  return flashcard;
};

export const generateExercise = async (card: FlashcardContent): Promise<Exercise> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Basé sur la fiche de révision intitulée "${card.title}" (${card.subject}, ${card.level}), génère 3 questions de type QCM pour tester la compréhension de l'élève. 
  Contenu de la fiche pour contexte : "${card.definition}. Points clés : ${card.keyPoints.join(', ')}."
  
  Chaque question doit avoir 4 options, une seule bonne réponse, et une explication pédagogique détaillée.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          questions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswerIndex: { type: Type.NUMBER },
                explanation: { type: Type.STRING }
              }
            }
          }
        }
      }
    }
  });

  const result = JSON.parse(response.text.trim());
  return {
    cardId: card.id,
    title: result.title || `Entraînement : ${card.title}`,
    questions: result.questions
  };
};
