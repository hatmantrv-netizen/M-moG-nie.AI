
import { Level, Subject } from './types';

export const LEVELS: Level[] = [
  '6ème', '5ème', '4ème', '3ème', 
  'Seconde', 'Première', 'Terminale'
];

export const SUBJECTS: Subject[] = [
  'Mathématiques', 
  'Français', 
  'Histoire-Géo', 
  'Physique-Chimie', 
  'SVT', 
  'Anglais', 
  'Espagnol',
  'Allemand',
  'Italien',
  'Chinois',
  'Japonais',
  'Russe',
  'Portugais',
  'Arabe',
  'Philosophie', 
  'SES',
  'Latin',
  'Grec ancien'
];
