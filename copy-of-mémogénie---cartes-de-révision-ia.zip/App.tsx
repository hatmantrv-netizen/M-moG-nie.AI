
import React, { useState, useEffect } from 'react';
import SelectionForm from './components/SelectionForm';
import Flashcard from './components/Flashcard';
import Gallery from './components/Gallery';
import ExerciseView from './components/ExerciseView';
import { SearchParams, FlashcardContent, Exercise } from './types';
import { generateFlashcard, generateExercise } from './geminiService';

type View = 'home' | 'generate' | 'gallery' | 'view-card' | 'view-exercise';

const App: React.FC = () => {
  const [view, setView] = useState<View>('home');
  const [loading, setLoading] = useState(false);
  const [exerciseLoading, setExerciseLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeCard, setActiveCard] = useState<FlashcardContent | null>(null);
  const [activeExercise, setActiveExercise] = useState<Exercise | null>(null);
  const [library, setLibrary] = useState<FlashcardContent[]>([]);

  // Chargement depuis le localStorage au démarrage
  useEffect(() => {
    const saved = localStorage.getItem('memogenie_cards');
    if (saved) {
      try {
        setLibrary(JSON.parse(saved));
      } catch (e) {
        console.error("Erreur lors du chargement de la bibliothèque", e);
      }
    }
  }, []);

  // Sauvegarde automatique à chaque changement de la bibliothèque
  useEffect(() => {
    localStorage.setItem('memogenie_cards', JSON.stringify(library));
  }, [library]);

  const handleGenerate = async (params: SearchParams) => {
    setLoading(true);
    setError(null);
    try {
      // On passe la bibliothèque actuelle comme mémoire à l'IA
      const result = await generateFlashcard(params, library);
      setLibrary(prev => [result, ...prev]);
      setActiveCard(result);
      setView('view-card');
    } catch (err) {
      console.error(err);
      setError("Désolé, une erreur est survenue lors de la rédaction. Réessaie !");
    } finally {
      setLoading(false);
    }
  };

  const handleStartExercise = async (card: FlashcardContent) => {
    setExerciseLoading(true);
    try {
      const exercise = await generateExercise(card);
      setActiveExercise(exercise);
      setView('view-exercise');
    } catch (err) {
      console.error(err);
      alert("Oups ! Impossible de préparer l'entraînement pour le moment.");
    } finally {
      setExerciseLoading(false);
    }
  };

  const deleteCard = (id: string) => {
    if (confirm("Supprimer cette fiche définitivement ?")) {
      setLibrary(prev => prev.filter(c => c.id !== id));
      if (activeCard?.id === id) {
        setView('gallery');
        setActiveCard(null);
      }
    }
  };

  const NavItem = ({ id, label, icon }: { id: View, label: string, icon: React.ReactNode }) => (
    <button 
      onClick={() => setView(id)}
      className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold transition-all ${
        (view === id || (id === 'gallery' && (view === 'view-card' || view === 'view-exercise')))
        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' 
        : 'text-slate-500 hover:text-indigo-600 hover:bg-indigo-50'
      }`}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24">
      {/* Navigation Flottante */}
      <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-xl border border-slate-200 px-3 py-2 rounded-3xl shadow-2xl flex gap-1 z-50 no-print">
        <NavItem id="home" label="Accueil" icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>} />
        <NavItem id="generate" label="Créer" icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>} />
        <NavItem id="gallery" label="Bibliothèque" icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 002-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>} />
      </nav>

      <header className="pt-12 pb-8 px-6 text-center no-print">
        <button 
          onClick={() => setView('gallery')}
          className="group transition-transform active:scale-95"
          title="Aller à ma bibliothèque"
        >
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-slate-950 mb-4 tracking-tight group-hover:text-indigo-600 transition-colors">
            Mémo<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 italic">Génie</span>
          </h1>
        </button>
        <p className="text-slate-600 text-lg font-medium max-w-2xl mx-auto">
          L'intelligence artificielle au service de ta réussite scolaire.
        </p>
      </header>

      <main className="px-6 max-w-7xl mx-auto">
        {view === 'home' && (
          <div className="py-12 animate-in fade-in zoom-in-95 duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <div className="space-y-8">
                <div className="inline-block px-4 py-2 bg-indigo-50 text-indigo-700 rounded-full text-xs font-black uppercase tracking-widest">
                  Nouveau : Générateur d'exercices
                </div>
                <h2 className="text-4xl md:text-6xl font-serif font-bold text-slate-900 leading-[1.1]">
                  Réviser n'a jamais été aussi <span className="underline decoration-indigo-500 decoration-4 underline-offset-8">efficace</span>.
                </h2>
                <p className="text-slate-600 text-xl leading-relaxed">
                  Génère des fiches de révision illustrées et teste tes connaissances avec des quiz interactifs personnalisés.
                </p>
                <div className="flex flex-wrap gap-4 pt-4">
                  <button onClick={() => setView('generate')} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition-all flex items-center gap-3">
                    Commencer maintenant
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
                  </button>
                  <button onClick={() => setView('gallery')} className="px-8 py-4 bg-white text-slate-800 border-2 border-slate-100 rounded-2xl font-bold hover:bg-slate-50 transition-all">
                    Ma bibliothèque ({library.length})
                  </button>
                </div>
              </div>
              <div className="hidden lg:block relative">
                <div className="absolute -inset-4 bg-gradient-to-tr from-indigo-100 to-purple-100 rounded-[4rem] -rotate-3 -z-10"></div>
                <div className="bg-white p-12 rounded-[3rem] shadow-2xl border border-slate-100 space-y-6 transform rotate-2">
                  <div className="h-3 w-20 bg-indigo-500 rounded-full"></div>
                  <div className="h-6 w-full bg-slate-50 rounded-lg"></div>
                  <div className="h-6 w-4/5 bg-slate-50 rounded-lg"></div>
                  <div className="aspect-video bg-indigo-50 rounded-3xl flex items-center justify-center">
                    <svg className="w-12 h-12 text-indigo-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                  </div>
                  <div className="flex gap-2">
                    <div className="h-8 w-24 bg-indigo-100 rounded-full"></div>
                    <div className="h-8 w-24 bg-slate-100 rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'generate' && (
          <div className="py-10">
            <SelectionForm onSearch={handleGenerate} isLoading={loading} />
            {error && (
              <div className="max-w-xl mx-auto mt-8 p-5 bg-red-50 border border-red-200 text-red-700 rounded-2xl text-center font-bold">
                {error}
              </div>
            )}
          </div>
        )}

        {view === 'gallery' && (
          <div className="py-10">
            <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-12">
              <h2 className="text-4xl font-serif font-bold text-slate-900">Ma Bibliothèque</h2>
              <div className="flex items-center gap-3">
                <span className="bg-slate-200 text-slate-600 px-4 py-1 rounded-full text-xs font-black uppercase tracking-widest">
                  {library.length} Fiches
                </span>
              </div>
            </header>
            <Gallery 
              cards={library} 
              onSelect={(card) => { setActiveCard(card); setView('view-card'); }} 
              onDelete={deleteCard}
            />
          </div>
        )}

        {view === 'view-card' && activeCard && (
          <Flashcard 
            content={activeCard} 
            onBack={() => setView('gallery')} 
            onDelete={deleteCard}
            onStartExercise={handleStartExercise}
            isExerciseLoading={exerciseLoading}
          />
        )}

        {view === 'view-exercise' && activeExercise && (
          <div className="py-10">
            <ExerciseView exercise={activeExercise} onClose={() => setView('view-card')} />
          </div>
        )}
      </main>

      <footer className="mt-20 py-12 border-t border-slate-200 px-6 text-center text-slate-400 text-sm no-print">
        <p>MémoGénie — Fait avec ❤️ pour ta réussite. Zéro faute garantie.</p>
      </footer>
    </div>
  );
};

export default App;
