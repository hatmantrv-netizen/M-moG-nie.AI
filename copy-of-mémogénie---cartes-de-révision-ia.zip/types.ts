
export type Level = 
  | '6ème' | '5ème' | '4ème' | '3ème' 
  | 'Seconde' | 'Première' | 'Terminale';

export type Subject = 
  | 'Mathématiques' 
  | 'Français' 
  | 'Histoire-Géo' 
  | 'Physique-Chimie' 
  | 'SVT' 
  | 'Anglais' 
  | 'Espagnol' 
  | 'Allemand'
  | 'Italien'
  | 'Chinois'
  | 'Japonais'
  | 'Russe'
  | 'Portugais'
  | 'Arabe'
  | 'Philosophie' 
  | 'SES'
  | 'Latin'
  | 'Grec ancien';

export interface SourceLink {
  title: string;
  uri: string;
}

export interface FlashcardContent {
  id: string;
  createdAt: number;
  level: Level;
  subject: Subject;
  title: string;
  subtitle: string;
  definition: string;
  keyPoints: string[];
  formulaOrExample: string;
  summary: string;
  mnemonicDevice?: string;
  imageDescription: string;
  imageUrl?: string;
  sources?: SourceLink[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface Exercise {
  cardId: string;
  title: string;
  questions: QuizQuestion[];
}

export interface SearchParams {
  level: Level;
  subject: Subject;
  topic: string;
}
